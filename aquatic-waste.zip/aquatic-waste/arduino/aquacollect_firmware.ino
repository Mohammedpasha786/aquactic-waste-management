/*
 * AquaCollect — Aquatic Waste Collector Firmware
 * Arduino/ESP8266 Firmware
 *
 * Hardware:
 *   - Ultrasonic Sensor (HC-SR04)  → Trig: D5, Echo: D6  — waste detection
 *   - IR Obstacle Sensor           → D7                   — proximity / surface check
 *   - Motor Driver L298N           → D1 (ENA), D2 (IN1), D3 (IN2)  — conveyor belt
 *   - Solar Charge Controller      → A0 (voltage divider)  — solar panel %
 *   - Water Level Sensor           → D8                   — flood detection
 *   - LED Status                   → D4 (built-in)
 *   - WiFi: ESP8266 built-in
 */

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <ArduinoJson.h>

// ── Wi-Fi credentials ──────────────────────────────────────────
const char* WIFI_SSID     = "YOUR_SSID";
const char* WIFI_PASSWORD = "YOUR_PASSWORD";
const char* DEVICE_ID     = "AWC-01";
const char* DEVICE_NAME   = "River Delta Unit";

// ── Pin definitions ────────────────────────────────────────────
#define TRIG_PIN        14   // D5
#define ECHO_PIN        12   // D6
#define IR_PIN          13   // D7
#define MOTOR_ENA        5   // D1 — PWM speed control
#define MOTOR_IN1        4   // D2
#define MOTOR_IN2        0   // D3
#define SOLAR_PIN       A0   // Analog solar voltage
#define WATER_LVL_PIN   15   // D8
#define LED_PIN          2   // D4 (active LOW)

// ── Thresholds ─────────────────────────────────────────────────
#define DETECT_DISTANCE_CM  40    // Detect waste within 40 cm
#define STORAGE_WARN_PCT    70
#define STORAGE_FULL_PCT    90
#define SOLAR_MIN_PCT       15    // Minimum solar to run conveyor
#define CONVEYOR_SPEED     200    // PWM 0-255
#define READ_INTERVAL_MS  4000

// ── Globals ────────────────────────────────────────────────────
ESP8266WebServer server(80);
bool conveyorOn    = false;
bool autoMode      = true;
bool wasteDetected = false;
float storagePct   = 0.0;
float solarPct     = 0.0;
float totalCollectedKg = 0.0;
unsigned long lastRead = 0;
unsigned long conveyorStartMs = 0;

// ── Ultrasonic distance ────────────────────────────────────────
float readDistance() {
  digitalWrite(TRIG_PIN, LOW);  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long dur = pulseIn(ECHO_PIN, HIGH, 30000);
  return dur == 0 ? 999.0 : dur * 0.034 / 2.0;
}

// ── Conveyor control ───────────────────────────────────────────
void setConveyor(bool state) {
  conveyorOn = state;
  if (state) {
    digitalWrite(MOTOR_IN1, HIGH);
    digitalWrite(MOTOR_IN2, LOW);
    analogWrite(MOTOR_ENA, CONVEYOR_SPEED);
    conveyorStartMs = millis();
    Serial.println("[CONV] Started");
  } else {
    analogWrite(MOTOR_ENA, 0);
    digitalWrite(MOTOR_IN1, LOW);
    digitalWrite(MOTOR_IN2, LOW);
    // Estimate kg collected: 0.03 kg/min average throughput
    float runMin = (millis() - conveyorStartMs) / 60000.0;
    totalCollectedKg += runMin * 0.03;
    Serial.printf("[CONV] Stopped. Total: %.3f kg\n", totalCollectedKg);
  }
}

// ── HTTP handlers ──────────────────────────────────────────────
void handleStatus() {
  StaticJsonDocument<256> doc;
  doc["id"]          = DEVICE_ID;
  doc["name"]        = DEVICE_NAME;
  doc["detected"]    = wasteDetected;
  doc["conveyor"]    = conveyorOn;
  doc["autoMode"]    = autoMode;
  doc["storage"]     = storagePct;
  doc["solar"]       = solarPct;
  doc["collected"]   = totalCollectedKg;
  doc["uptime"]      = millis() / 1000;
  String out; serializeJson(doc, out);
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", out);
}

void handleConveyor() {
  if (!server.hasArg("state")) { server.send(400, "application/json", "{\"error\":\"Missing state\"}"); return; }
  autoMode = false;
  setConveyor(server.arg("state") == "on");
  server.send(200, "application/json", "{\"ok\":true}");
}

void handleAuto() {
  autoMode = server.hasArg("enabled") && server.arg("enabled") == "true";
  server.send(200, "application/json", "{\"ok\":true}");
}

void handleReset() {
  totalCollectedKg = 0.0; storagePct = 0.0;
  server.send(200, "application/json", "{\"ok\":true,\"msg\":\"Storage reset\"}");
}

// ── Setup ──────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  Serial.println("\n[AquaCollect] Booting...");

  pinMode(TRIG_PIN, OUTPUT); pinMode(ECHO_PIN, INPUT);
  pinMode(IR_PIN, INPUT_PULLUP);
  pinMode(MOTOR_IN1, OUTPUT); pinMode(MOTOR_IN2, OUTPUT);
  pinMode(MOTOR_ENA, OUTPUT); analogWrite(MOTOR_ENA, 0);
  pinMode(WATER_LVL_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT); digitalWrite(LED_PIN, HIGH);

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("[WiFi] Connecting");
  int tries = 0;
  while (WiFi.status() != WL_CONNECTED && tries < 30) {
    delay(500); Serial.print("."); tries++;
  }
  if (WiFi.status() == WL_CONNECTED)
    Serial.printf("\n[WiFi] IP: %s\n", WiFi.localIP().toString().c_str());
  else
    Serial.println("\n[WiFi] Offline mode");

  server.on("/status",   HTTP_GET, handleStatus);
  server.on("/conveyor", HTTP_GET, handleConveyor);
  server.on("/auto",     HTTP_GET, handleAuto);
  server.on("/reset",    HTTP_GET, handleReset);
  server.begin();
  Serial.println("[HTTP] Ready on port 80");
}

// ── Main loop ──────────────────────────────────────────────────
void loop() {
  server.handleClient();

  if (millis() - lastRead >= READ_INTERVAL_MS) {
    lastRead = millis();

    // Read sensors
    float dist    = readDistance();
    bool  irHit   = digitalRead(IR_PIN) == LOW;
    int   solarRaw = analogRead(SOLAR_PIN);  // 0-1023
    solarPct = (solarRaw / 1023.0) * 100.0;

    // Waste detected if ultrasonic < threshold OR IR triggered
    wasteDetected = (dist < DETECT_DISTANCE_CM) || irHit;

    // Simulate storage increase when conveyor runs
    if (conveyorOn) storagePct = min(100.0f, storagePct + 0.15f);

    Serial.printf("[SENSOR] dist=%.1fcm ir=%d waste=%d solar=%.0f%% storage=%.1f%%\n",
                  dist, irHit, wasteDetected, solarPct, storagePct);

    // Auto mode logic
    if (autoMode) {
      if (storagePct >= STORAGE_FULL_PCT) {
        if (conveyorOn) setConveyor(false);
        digitalWrite(LED_PIN, LOW);  // Blink LED — full alert
        Serial.println("[AUTO] Storage FULL — halting");
      } else if (wasteDetected && !conveyorOn && solarPct >= SOLAR_MIN_PCT) {
        setConveyor(true);
      } else if (!wasteDetected && conveyorOn) {
        setConveyor(false);
      }
    }
    digitalWrite(LED_PIN, wasteDetected ? LOW : HIGH);
  }
}
