# 🔌 Wiring Diagram — AquaCollect

## Full Schematic (ASCII)

```
                      ┌──────────────────────────────┐
                      │        NodeMCU ESP8266        │
                      │                               │
  ┌─────────────┐     │  D5 (GPIO14) ── TRIG          │
  │  HC-SR04    │─────│  D6 (GPIO12) ── ECHO          │  Waste detection
  │  Ultrasonic │     │  3.3V ──────── VCC            │
  └─────────────┘     │  GND ──────── GND             │
                      │                               │
  ┌─────────────┐     │  D7 (GPIO13) ── OUT           │  Secondary detect
  │  IR Sensor  │─────│  3.3V ──────── VCC            │
  └─────────────┘     │  GND ──────── GND             │
                      │                               │
  ┌─────────────┐     │  D1 (GPIO5)  ── ENA (PWM)     │
  │   L298N     │─────│  D2 (GPIO4)  ── IN1           │  Conveyor motor
  │   Motor     │     │  D3 (GPIO0)  ── IN2           │
  │   Driver    │     │  VIN (5V) ─── VSS             │
  └─────────────┘     │  GND ──────── GND             │
        │             │                               │
  ┌─────┴──────┐      │  A0 ────────── Solar V-Div    │  Solar monitor
  │ DC Gear    │      │  D8 (GPIO15) ── Water Sensor  │
  │ Motor 5V   │      │  D4 ──────── Built-in LED     │
  └────────────┘      └──────────────────────────────┘
```

## Component Pin Reference

### HC-SR04 Ultrasonic Sensor
| HC-SR04 | NodeMCU |
|---|---|
| VCC | 3.3V or 5V (use voltage divider on ECHO if 5V) |
| TRIG | D5 (GPIO14) |
| ECHO | D6 (GPIO12) |
| GND | GND |

> If using 5V on VCC, add a voltage divider on ECHO:  
> ECHO → 1kΩ → GPIO12 → 2kΩ → GND

### L298N Motor Driver
| L298N | NodeMCU | Notes |
|---|---|---|
| ENA | D1 (GPIO5) | PWM speed (0-255) |
| IN1 | D2 (GPIO4) | Direction A |
| IN2 | D3 (GPIO0) | Direction B |
| VSS | VIN | 5–12V motor supply |
| GND | GND | Common ground |
| OUT1, OUT2 | Conveyor Motor | — |

### Solar Panel Monitor (Voltage Divider)
```
Solar panel + ──── 10kΩ ──── A0 ──── 10kΩ ──── GND
```
Scales panel voltage (0–4.2V) to safe 0–1V ADC range.

### IR Obstacle Sensor
| IR Sensor | NodeMCU |
|---|---|
| VCC | 3.3V |
| GND | GND |
| OUT | D7 (GPIO13) |

### Water Level / Flood Sensor
| Sensor | NodeMCU |
|---|---|
| + | D8 (GPIO15) with INPUT_PULLUP |
| - | GND |

## Power Supply (Field Deployment)

```
Solar Panel (6V 2W)
        │
  TP4056 + 18650 Li-Ion
        │
  MT3608 Boost → 5V 1A
        │
  NodeMCU VIN  +  L298N VSS
```

Ensure common GND across all modules.

## Waterproofing Notes

- Enclose NodeMCU in IP65 waterproof box
- Use cable glands for wire entry points
- Apply conformal coating on PCB
- Mount ultrasonic sensor facing downward toward water surface
- Float housing: sealed foam/PVC tube rated for 2–5 kg payload
