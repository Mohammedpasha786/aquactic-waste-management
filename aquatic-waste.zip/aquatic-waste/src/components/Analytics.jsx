import { SAMPLE_LOGS, WASTE_TYPES } from "../data/wasteData";
import { estimateImpact } from "../utils/deviceLogic";

export default function Analytics({ history, devices, totalCollected }) {
  const maxCollected = Math.max(...history.map(h => h.collected), 0.1);
  const maxSolar = 100;
  const impact = estimateImpact(totalCollected);

  // Points for collected line
  const pts = history.map((h, i) =>
    `${(i / (history.length - 1)) * 380},${100 - (h.collected / maxCollected) * 90}`
  ).join(" ");
  const poly = [
    ...history.map((h, i) => `${(i / (history.length - 1)) * 380},${100 - (h.collected / maxCollected) * 90}`),
    "380,100", "0,100"
  ].join(" ");

  const detectedHours = history.filter(h => h.detected).length;

  return (
    <div className="page fade">
      <div className="section-title"><h2>Analytics</h2><span>24-hour performance data</span></div>

      {/* KPI row */}
      <div className="kpi-row">
        <KPI label="Detection Rate" value={`${Math.round(detectedHours / history.length * 100)}%`} sub={`${detectedHours} / ${history.length} hours`} />
        <KPI label="Total Collected" value={`${totalCollected.toFixed(2)} kg`} sub="All units" />
        <KPI label="Peak Collection" value={`${Math.max(...history.map(h => h.collected)).toFixed(2)} kg`} sub="Single hour high" />
        <KPI label="Avg Solar" value={`${(history.reduce((a,h)=>a+h.solar,0)/history.length).toFixed(0)}%`} sub="Panel efficiency" />
      </div>

      {/* Charts */}
      <div className="chart-duo">
        <div className="chart-box">
          <h3>Hourly Waste Collected (kg)</h3>
          <svg viewBox="0 0 400 110" className="lsvg" preserveAspectRatio="none">
            <defs>
              <linearGradient id="cg" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#0ea5e9" stopOpacity=".35" />
                <stop offset="100%" stopColor="#0ea5e9" stopOpacity="0" />
              </linearGradient>
            </defs>
            <polygon points={poly} fill="url(#cg)" />
            <polyline points={pts} fill="none" stroke="#0ea5e9" strokeWidth="2" strokeLinejoin="round" />
          </svg>
          <div className="chart-xlabels">
            {history.filter((_, i) => i % 4 === 0).map(h => (
              <span key={h.time}>{h.time}</span>
            ))}
          </div>
        </div>

        <div className="chart-box">
          <h3>Solar Power Level (%)</h3>
          <div className="bar-chart">
            {history.map((h, i) => (
              <div key={i} className="bcol">
                <div className="bbar" style={{
                  height: `${(h.solar / maxSolar) * 100}%`,
                  background: h.solar > 60 ? "#facc15" : h.solar > 20 ? "#fb923c" : "#94a3b8"
                }} />
                {i % 4 === 0 && <div className="blbl">{h.time}</div>}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sample data table from spec */}
      <div className="section-title" style={{ marginTop: "2rem" }}>
        <h2>Sample Session Log</h2>
        <span>From project dataset</span>
      </div>
      <div className="tbl-wrap">
        <table className="dtable">
          <thead><tr><th>Time</th><th>Waste Detected</th><th>Collected (kg)</th><th>Status</th></tr></thead>
          <tbody>
            {SAMPLE_LOGS.map((r, i) => (
              <tr key={i}>
                <td className="td-time">{r.time}</td>
                <td><span className={`ptag ${r.detected ? "yes" : "no"}`}>{r.detected ? "✓ YES" : "✗ NO"}</span></td>
                <td className="td-kg">{r.collected.toFixed(1)} kg</td>
                <td style={{ color: r.detected ? "#0ea5e9" : "#64748b" }}>{r.detected ? "Collecting" : "Standby"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Waste types donut-style */}
      <div className="section-title" style={{ marginTop: "2rem" }}><h2>Waste Type Distribution</h2></div>
      <div className="waste-breakdown">
        {WASTE_TYPES.map(w => (
          <div key={w.label} className="wbd-row">
            <span className="wbd-dot" style={{ background: w.color }} />
            <span className="wbd-lbl">{w.label}</span>
            <div className="wbd-track"><div className="wbd-fill" style={{ width: `${w.pct}%`, background: w.color }} /></div>
            <span className="wbd-pct" style={{ color: w.color }}>{w.pct}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function KPI({ label, value, sub }) {
  return (
    <div className="kpi">
      <div className="kpi-val">{value}</div>
      <div className="kpi-lbl">{label}</div>
      <div className="kpi-sub">{sub}</div>
    </div>
  );
}
