import { storageStatus, powerStatus } from "../utils/deviceLogic";

export default function DeviceCard({ device: d, onToggle, onConveyor, expanded = false }) {
  const storage = storageStatus(d.storage);
  const power = powerStatus(d.solar);

  return (
    <div className={`dcard ${d.active ? "dactive" : "dinactive"} ${d.detected ? "ddetect" : ""}`}>
      {/* Header row */}
      <div className="dcard-top">
        <div>
          <div className="did">{d.id}</div>
          <div className="dname">{d.name}</div>
          <div className="dloc">📍 {d.location}</div>
        </div>
        <div className="dstatus-col">
          <span className={`dbadge ${d.active ? "on" : "off"}`}>
            {d.active ? "● ACTIVE" : "○ OFFLINE"}
          </span>
          {d.detected && d.active && <span className="detect-pulse">WASTE DETECTED</span>}
        </div>
      </div>

      {/* Metric row */}
      <div className="dmetrics">
        <Metric label="Collected Today" value={`${d.collected.toFixed(2)} kg`} accent="#0ea5e9" />
        <Metric label="Storage" value={`${d.storage.toFixed(0)}%`} accent={storage.color} sub={storage.label} />
        <Metric label="Solar" value={`${d.solar.toFixed(0)}%`} accent={power.color} sub={power.icon} />
        <Metric label="Conveyor" value={d.conveyor && d.active ? "RUNNING" : "IDLE"} accent={d.conveyor && d.active ? "#10b981" : "#475569"} />
      </div>

      {/* Storage bar */}
      <div className="storage-bar-wrap">
        <div className="storage-bar">
          <div className="storage-fill" style={{ width: `${d.storage}%`, background: storage.color }} />
        </div>
        <span className="storage-action">{storage.action}</span>
      </div>

      {/* Controls */}
      <div className="dcontrols">
        <button className={`dbtn ${d.active ? "danger" : "primary"}`} onClick={onToggle}>
          {d.active ? "⏹ Deactivate" : "▶ Activate"}
        </button>
        <button
          className={`dbtn ${d.conveyor && d.active ? "warn" : "secondary"}`}
          onClick={onConveyor}
          disabled={!d.active}
        >
          {d.conveyor && d.active ? "⏸ Stop Conveyor" : "⚙ Start Conveyor"}
        </button>
      </div>
    </div>
  );
}

function Metric({ label, value, accent, sub }) {
  return (
    <div className="dmetric">
      <div className="dm-val" style={{ color: accent }}>{value}</div>
      <div className="dm-lbl">{label}</div>
      {sub && <div className="dm-sub">{sub}</div>}
    </div>
  );
}
