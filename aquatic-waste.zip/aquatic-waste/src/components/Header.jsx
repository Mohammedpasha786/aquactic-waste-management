export default function Header({ tab, setTab, time, alertCount, tabs }) {
  return (
    <header className="header">
      <div className="logo">
        <span className="logo-mark">◈</span>
        <div>
          <h1>AquaCollect</h1>
          <p>Aquatic Waste Management System</p>
        </div>
      </div>
      <nav className="nav">
        {tabs.map(t => (
          <button
            key={t}
            className={`nb ${tab === t ? "act" : ""}`}
            onClick={() => setTab(t)}
          >
            {t.charAt(0).toUpperCase() + t.slice(1)}
            {t === "logs" && alertCount > 0 && <span className="badge">{alertCount}</span>}
          </button>
        ))}
      </nav>
      <div className="hright">
        <span className="status-dot" />
        <span className="status-label">3 Units Online</span>
        <div className="clk">{time.toLocaleTimeString()}</div>
      </div>
    </header>
  );
}
