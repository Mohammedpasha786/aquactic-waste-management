import DeviceCard from "./DeviceCard";

export default function LiveFeed({ devices, toggleDevice, toggleConveyor }) {
  return (
    <div className="page fade">
      <div className="section-title">
        <h2>Live Device Feed</h2>
        <span>Real-time sensor streams</span>
      </div>

      {/* Live water surface simulation */}
      <div className="water-viz">
        <div className="water-surface">
          {devices.map((d, i) => (
            <div
              key={d.id}
              className={`water-unit ${d.detected ? "wdetect" : ""} ${!d.active ? "woff" : ""}`}
              style={{ left: `${20 + i * 28}%`, top: `${30 + (i % 2) * 20}%` }}
            >
              <div className="wunit-body">
                <span className="wunit-icon">{d.active ? (d.conveyor ? "⚙" : "◈") : "○"}</span>
              </div>
              <div className="wunit-label">{d.id}</div>
              {d.detected && <div className="wunit-ring" />}
            </div>
          ))}
          {/* Floating debris dots */}
          {Array.from({ length: 12 }, (_, i) => (
            <div key={i} className="debris" style={{
              left: `${10 + Math.sin(i * 1.7) * 35 + 35}%`,
              top: `${15 + Math.cos(i * 1.3) * 25 + 30}%`,
              animationDelay: `${i * 0.4}s`,
              width: `${4 + (i % 4)}px`, height: `${4 + (i % 4)}px`,
              opacity: 0.4 + (i % 3) * 0.15,
            }} />
          ))}
          <div className="water-label">Water Surface — Live View</div>
        </div>
      </div>

      <div className="device-grid full">
        {devices.map(d => (
          <DeviceCard key={d.id} device={d}
            onToggle={() => toggleDevice(d.id)}
            onConveyor={() => toggleConveyor(d.id)}
            expanded
          />
        ))}
      </div>
    </div>
  );
}
