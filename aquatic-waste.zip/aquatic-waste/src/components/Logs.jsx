export default function Logs({ alerts, onClear }) {
  const typeColor = { success: "#10b981", warning: "#f59e0b", danger: "#ef4444", info: "#0ea5e9" };
  return (
    <div className="page fade">
      <div className="section-title">
        <h2>Event Log</h2>
        <div style={{ display: "flex", gap: "1rem", alignItems: "center" }}>
          <span style={{ fontSize: ".75rem", color: "var(--text3)" }}>{alerts.length} events</span>
          {alerts.length > 0 && <button className="clear-btn" onClick={onClear}>Clear All</button>}
        </div>
      </div>
      {alerts.length === 0
        ? <div className="empty-state"><div className="empty-icon">🌊</div><p>System is monitoring. No events yet.</p></div>
        : <div className="log-list">
            {alerts.map(a => (
              <div key={a.id} className="log-item">
                <span className="log-dot" style={{ background: typeColor[a.type] || "#0ea5e9" }} />
                <div className="log-body">
                  <div className="log-msg">{a.msg}</div>
                  <div className="log-time">{a.time}</div>
                </div>
                <span className={`log-type lt-${a.type}`}>{a.type.toUpperCase()}</span>
              </div>
            ))}
          </div>
      }
    </div>
  );
}
