import DeviceCard from "./DeviceCard";
import { estimateImpact } from "../utils/deviceLogic";
import { WASTE_TYPES } from "../data/wasteData";

export default function Overview({ devices, history, totalCollected, toggleDevice, toggleConveyor }) {
  const impact = estimateImpact(totalCollected);
  const activeUnits = devices.filter(d => d.active).length;
  const detecting = devices.filter(d => d.detected && d.active).length;
  const avgStorage = (devices.reduce((a, d) => a + d.storage, 0) / devices.length).toFixed(0);

  return (
    <div className="page fade">
      {/* Hero stats */}
      <div className="hero-stats">
        <HeroStat icon="🌊" label="Total Collected" value={`${totalCollected.toFixed(2)} kg`} sub="All units combined" color="blue" />
        <HeroStat icon="🤖" label="Units Active" value={`${activeUnits} / ${devices.length}`} sub="Online now" color="teal" />
        <HeroStat icon="🔍" label="Detecting Waste" value={`${detecting} unit${detecting !== 1 ? "s" : ""}`} sub="Active scans" color="amber" />
        <HeroStat icon="🗑️" label="Avg Storage" value={`${avgStorage}%`} sub="Container fullness" color="cyan" />
      </div>

      {/* Environmental impact */}
      <div className="impact-band">
        <div className="impact-title">Environmental Impact Today</div>
        <div className="impact-row">
          <ImpactPill icon="🍶" label="Bottles prevented" val={impact.bottles} />
          <ImpactPill icon="🐟" label="Fish protected (est.)" val={impact.fishSaved} />
          <ImpactPill icon="🌿" label={`CO₂ equivalent`} val={`${impact.co2Eq} kg`} />
          <ImpactPill icon="⏱️" label="Operating hours" val={`${(totalCollected / 1.2 * 0.8).toFixed(0)}h`} />
        </div>
      </div>

      {/* Device grid */}
      <div className="section-title"><h2>Active Units</h2><span>{devices.length} devices deployed</span></div>
      <div className="device-grid">
        {devices.map(d => (
          <DeviceCard key={d.id} device={d}
            onToggle={() => toggleDevice(d.id)}
            onConveyor={() => toggleConveyor(d.id)}
          />
        ))}
      </div>

      {/* Waste composition */}
      <div className="section-title"><h2>Waste Composition</h2><span>Surface debris breakdown</span></div>
      <div className="waste-comp">
        {WASTE_TYPES.map(w => (
          <div key={w.label} className="wtype">
            <div className="wtype-bar-wrap">
              <div className="wtype-bar" style={{ width: `${w.pct}%`, background: w.color }} />
            </div>
            <div className="wtype-label">{w.label}</div>
            <div className="wtype-pct" style={{ color: w.color }}>{w.pct}%</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function HeroStat({ icon, label, value, sub, color }) {
  return (
    <div className={`hstat hstat-${color}`}>
      <div className="hstat-icon">{icon}</div>
      <div className="hstat-val">{value}</div>
      <div className="hstat-lbl">{label}</div>
      <div className="hstat-sub">{sub}</div>
    </div>
  );
}

function ImpactPill({ icon, label, val }) {
  return (
    <div className="ipill">
      <span className="ipill-icon">{icon}</span>
      <div>
        <div className="ipill-val">{val}</div>
        <div className="ipill-lbl">{label}</div>
      </div>
    </div>
  );
}
