/**
 * AquaCollect — Device Logic Utilities
 * Mirrors the Arduino firmware decision logic
 */

export const THRESHOLDS = {
  STORAGE_WARN:    70,   // % — show warning
  STORAGE_FULL:    90,   // % — halt collection, return to dock
  SOLAR_LOW:       20,   // % — switch to battery reserve
  DETECTION_CONF:  0.75, // confidence threshold for waste detection
};

export function storageStatus(pct) {
  if (pct >= THRESHOLDS.STORAGE_FULL)  return { label: "Full",    color: "#ef4444", action: "Return to dock" };
  if (pct >= THRESHOLDS.STORAGE_WARN)  return { label: "High",    color: "#f59e0b", action: "Plan collection soon" };
  if (pct >= 40)                        return { label: "Moderate",color: "#0ea5e9", action: "Operating normally" };
  return                                       { label: "Low",     color: "#10b981", action: "Operating normally" };
}

export function powerStatus(solar) {
  if (solar >= 60) return { label: "Solar",   color: "#facc15", icon: "☀️" };
  if (solar >= 20) return { label: "Mixed",   color: "#fb923c", icon: "🌤️" };
  return                  { label: "Battery", color: "#94a3b8", icon: "🔋" };
}

export function formatKg(kg) {
  return kg >= 1 ? `${kg.toFixed(2)} kg` : `${(kg * 1000).toFixed(0)} g`;
}

export function estimateImpact(totalKg) {
  // 1 kg plastic ≈ 20 plastic bottles saved from water
  return {
    bottles: Math.round(totalKg * 20),
    fishSaved: Math.round(totalKg * 4),
    co2Eq: parseFloat((totalKg * 6).toFixed(1)),
  };
}
